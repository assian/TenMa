const express = require('express');
const path = require('path');
const fs = require('fs');
const fetch = require('node-fetch').default;
const cors = require('cors');
const app = express();

// Middleware
app.use(cors({
  origin: true,
  credentials: true,
  methods: ['GET', 'POST', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Favoriler için dosya yolu
const FAVORITES_PATH = path.join(__dirname, 'favorites.json');

// Favorileri yönetmek için yardımcı fonksiyon
const readFavorites = () => {
  try {
    if (!fs.existsSync(FAVORITES_PATH)) {
      fs.writeFileSync(FAVORITES_PATH, '{}');
      return {};
    }
    return JSON.parse(fs.readFileSync(FAVORITES_PATH));
  } catch (error) {
    console.error('Favoriler okunurken hata:', error);
    return {};
  }
};

// Favorileri getir
app.get('/favorites.json', (req, res) => {
  try {
    const favorites = readFavorites();
    res.json(favorites);
  } catch (error) {
    res.status(500).json({ error: 'Favoriler yüklenemedi' });
  }
});

// Favorileri kaydet
app.post('/save-favorites', (req, res) => {
  try {
    fs.writeFileSync(FAVORITES_PATH, JSON.stringify(req.body, null, 2));
    res.json({ success: true });
  } catch (error) {
    console.error('Favoriler kaydedilirken hata:', error);
    res.status(500).json({ error: 'Favoriler kaydedilemedi' });
  }
});

// Favori ekle/sil
// server.js içinde /api/favorites endpoint'ini güncelleyin
app.post('/api/favorites', (req, res) => {
  try {
    const { action, video } = req.body;
    const favorites = readFavorites();

    if (action === 'add') {
      // URL'nin de eklenmesini sağlıyoruz
      if (!video.url) {
        return res.status(400).json({ error: 'Video URL eksik' });
      }
      
      favorites[video.id] = {
        id: video.id,
        title: video.title || 'İsimsiz Video',
        thumbnail: video.thumbnail || '/placeholder.jpg',
        url: video.url, // URL'yi kaydediyoruz
        date: new Date().toISOString()
      };
    } else if (action === 'remove') {
      delete favorites[video.id];
    }

    fs.writeFileSync(FAVORITES_PATH, JSON.stringify(favorites, null, 2));
    res.json({ success: true, favorites });
  } catch (error) {
    console.error('Favori işlemi sırasında hata:', error);
    res.status(500).json({ error: 'Favori işlemi başarısız' });
  }
});

// ... (Mevcut proxy ve diğer endpoint'ler aynen kalacak) ...

// Proxy endpoint to handle CORS issues
app.get('/proxy', async (req, res) => {
  try {
    // Validate URL parameter exists
    if (!req.query.url) {
      return res.status(400).json({ error: 'Missing URL parameter' });
    }

    // Decode and validate URL
    let url;
    try {
      url = decodeURIComponent(req.query.url);
      new URL(url); // This will throw if URL is invalid
    } catch (e) {
      return res.status(400).json({ error: 'Invalid URL format' });
    }

    const userAgent = req.query.ua || 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';
    
    console.log(`Proxying to: ${url}`);
    
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 15000);

    const response = await fetch(url, {
      headers: { 
        'User-Agent': userAgent,
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8'
      },
      signal: controller.signal
    });
    
    clearTimeout(timeout);
    
    if (!response.ok) {
      throw new Error(`HTTP ${response.status} ${response.statusText}`);
    }
    
    const content = await response.text();
    res.send(content);
  } catch (error) {
    console.error('Proxy error:', error);
    const status = error.message.includes('URL') ? 400 : 500;
    res.status(status).json({ 
      error: error.message,
      details: error.name === 'AbortError' ? 'Request timed out' : undefined
    });
  }
});
// API endpoint to get sources
app.get('/api/sources', (req, res) => {
  const fs = require('fs');
  try {
    const sources = JSON.parse(fs.readFileSync('./sources.json'));
    res.json(sources);
  } catch (error) {
    console.error('Error reading sources:', error);
    res.status(500).json({ error: 'Failed to load sources' });
  }
});

// API endpoint to update sources
app.post('/api/sources', (req, res) => {
  const fs = require('fs');
  try {
    fs.writeFileSync('./sources.json', JSON.stringify(req.body, null, 2));
    res.json({ success: true });
  } catch (error) {
    console.error('Error saving sources:', error);
    res.status(500).json({ error: 'Failed to save sources' });
  }
});

app.get('/test-source', async (req, res) => {
  try {
    const source = require('./sources.json')[0];
    const testUrl = source.listUrl.replace('${page}', '1');
    
    const response = await fetch(`/proxy?url=${encodeURIComponent(testUrl)}&ua=${source.userAgent}`);
    const html = await response.text();
    
    const parser = new DOMParser();
    const doc = parser.parseFromString(html, 'text/html');
    
    const videoItems = doc.querySelectorAll(source.videoItemSelector);
    const results = [];
    
    videoItems.forEach(item => {
      const titleElement = item.querySelector(source.titleSelector);
      const thumbnailElement = item.querySelector(source.thumbnailSelector);
      
      results.push({
        title: titleElement ? titleElement.getAttribute('title') || titleElement.textContent.trim() : 'No title',
        thumbnail: thumbnailElement ? thumbnailElement.getAttribute('data-original') || thumbnailElement.getAttribute('src') : 'No thumbnail'
      });
    });
    
    res.json({
      success: true,
      itemsFound: videoItems.length,
      testItems: results.slice(0, 3), // Show first 3 items as sample
      htmlSample: html.substring(0, 500) + '...' // Show first 500 chars of HTML
    });
  } catch (error) {
    res.json({
      success: false,
      error: error.message
    });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
