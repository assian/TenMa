let currentPage = 1;
let isLoading = false;
let currentQuery = null; // null = normal listeleme, string = arama

document.addEventListener('DOMContentLoaded', async () => {
    window.addEventListener('load', () => {
        setTimeout(() => {
            document.getElementById('loading-screen').style.display = 'none';
        }, 500);
    });

    const navButtons = document.querySelectorAll('.nav-btn');
    navButtons.forEach(button => {
        button.addEventListener('click', () => {
            const pageId = button.getAttribute('data-page');
            showPage(pageId);
            navButtons.forEach(btn => btn.classList.remove('active'));
            button.classList.add('active');
        });
    });

    await SourcesManager.init();
    await FavoritesManager.init();
    await loadVideos(1);

    document.getElementById('add-source-btn').addEventListener('click', async () => {
        const url = document.getElementById('source-url').value;
        if (url) {
            try {
                await SourcesManager.addSource(url);
                document.getElementById('source-url').value = '';
                await SourcesManager.init();
                resetList();
                await loadVideos(1);
            } catch (error) {
                console.error('Error adding source:', error);
                alert('Kaynak eklenemedi. URL kontrol edin.');
            }
        }
    });

    document.getElementById('search-btn').addEventListener('click', () => performSearch(1));
    document.getElementById('search-input').addEventListener('keypress', (e) => {
        if (e.key === 'Enter') performSearch(1);
    });

    setTimeout(() => {
        if (!VideoPlayer.init()) {
            console.error('VideoPlayer initialization failed after retry');
        }
    }, 500);

    // Virtual scroll
    window.addEventListener('scroll', async () => {
        if (isLoading) return;
        if ((window.innerHeight + window.scrollY) >= document.body.offsetHeight - 200) {
            isLoading = true;
            currentPage++;
            if (currentQuery) {
                await performSearch(currentPage, true);
            } else {
                await loadVideos(currentPage, true);
            }
            isLoading = false;
        }
    });
});

function resetList() {
    currentPage = 1;
    document.getElementById('video-list').innerHTML = '';
}

function showPage(pageId) {
    document.querySelectorAll('.page').forEach(page => page.classList.remove('active'));
    document.getElementById(`${pageId}-page`).classList.add('active');
    if (pageId === 'favorites') FavoritesManager.displayFavorites();
}

// --- Arama ---
async function performSearch(page = 1, append = false) {
    const query = page === 1 ? document.getElementById('search-input').value.trim() : currentQuery;
    if (!query) {
        alert('Lütfen arama terimi girin');
        return;
    }
    currentQuery = query;

    try {
        const activeSource = SourcesManager.getActiveSource();
        if (!activeSource?.searchUrl) throw new Error('Bu kaynakta arama desteklenmiyor');

        const searchUrl = activeSource.searchUrl
            .replace('${query}', encodeURIComponent(query))
            .replace('${page}', page);

        await loadVideosFromUrl(searchUrl, page, append);
    } catch (error) {
        console.error('Arama hatası:', error);
        document.getElementById('video-list').innerHTML = `
        <div class="error">
            <p>${error.message}</p>
            <button onclick="resetList(); loadVideos(1)">Ana Sayfaya Dön</button>
        </div>`;
    }
}

// --- Video Listesi (Search veya Normal) ---
async function loadVideosFromUrl(url, page = 1, append = false) {
    try {
        const activeSource = SourcesManager.getActiveSource();
        if (!activeSource) throw new Error('No active source selected.');

        const videoList = document.getElementById('video-list');
        if (!append) videoList.innerHTML = '<div class="loading">Loading videos...</div>';

        const response = await fetch(`/proxy?url=${encodeURIComponent(url)}&ua=${encodeURIComponent(activeSource.userAgent)}`);
        if (!response.ok) throw new Error(`Server returned ${response.status} ${response.statusText}`);

        const html = await response.text();
        const parser = new DOMParser();
        const doc = parser.parseFromString(html, 'text/html');

        const videoItems = doc.querySelectorAll(activeSource.videoItemSelector);
        if (videoItems.length === 0) {
            if (!append) throw new Error('No videos found.');
            return;
        }

        if (!append) videoList.innerHTML = '';

        for (const item of videoItems) {
            const titleElement = item.querySelector(activeSource.titleSelector);
            const thumbnailElement = item.querySelector(activeSource.thumbnailSelector);
            const linkElement = item.querySelector(activeSource.detailPageLinkSelector);

            if (!titleElement || !thumbnailElement || !linkElement) continue;

            const title = titleElement.getAttribute('title') || titleElement.textContent.trim();
            const thumbnail = thumbnailElement.getAttribute('data-original') || thumbnailElement.getAttribute('src');
            const href = linkElement.getAttribute('href');
            const detailUrl = href.startsWith('http') ? href : new URL(href, activeSource.baseUrl).href;

            const videoCard = document.createElement('div');
            videoCard.className = 'video-card';
            videoCard.dataset.detailUrl = detailUrl;
            videoCard.innerHTML = `
                <div class="video-thumbnail">
                    <img src="${thumbnail || '/placeholder.jpg'}" alt="${title}" onerror="this.src='/placeholder.jpg'">
                </div>
                <div class="video-title">${title}</div>
            `;

            videoCard.addEventListener('click', async (e) => {
                if (e.target.closest('.favorite-btn')) return;
                try {
                    const videoUrl = await getVideoUrl(detailUrl, activeSource);
                    VideoPlayer.play(videoUrl, { detailUrl, title, thumbnail });
                } catch (err) {
                    alert('Video yüklenemedi: ' + err.message);
                }
            });

            videoList.appendChild(videoCard);
        }

        FavoritesManager.initFavoriteButtons();

    } catch (error) {
        console.error('Error loading videos:', error);
        if (!append) {
            document.getElementById('video-list').innerHTML = `
            <div class="error">
                <p>${error.message}</p>
                <button onclick="resetList(); loadVideos(1)">Try Again</button>
            </div>`;
        }
    }
}

// --- Normal Listeleme ---
async function loadVideos(page = 1, append = false) {
    currentQuery = null; // normal mod
    const activeSource = SourcesManager.getActiveSource();
    if (!activeSource) {
        document.getElementById('video-list').innerHTML = '<p>Kaynak seçilmedi.</p>';
        return;
    }

    const listUrl = activeSource.listUrl.replace('${page}', page);
    await loadVideosFromUrl(listUrl, page, append);
}

// --- Video URL Alma ---
async function getVideoUrl(detailUrl, source) {
    try {
        console.log('Fetching video details from:', detailUrl);
        const response = await fetch(`/proxy?url=${encodeURIComponent(detailUrl)}&ua=${encodeURIComponent(source.userAgent)}`);
        if (!response.ok) throw new Error(`HTTP ${response.status} ${response.statusText}`);

        const html = await response.text();
        if (!html) throw new Error('Empty response');

        const parser = new DOMParser();
        const doc = parser.parseFromString(html, 'text/html');

        // 1. Script regex kontrolü
        if (source.videoPlayerRegex) {
            const scripts = doc.querySelectorAll('script');
            for (const script of scripts) {
                const text = script.textContent;
                const regex = new RegExp(source.videoPlayerRegex);
                const match = text.match(regex);

                if (match && (match[1] || match[2])) {
                    let url = match[1] || match[2];
                    url = url.replace(/\\\//g, '/').replace(/^\/\//, 'https://');
                    console.log('✅ Found video via regex:', url);
                    return url;
                }
            }
        }

        // 2. <video> etiketi
        const videoTag = doc.querySelector('video source') || doc.querySelector('video');
        if (videoTag) {
            const src = videoTag.getAttribute('src');
            if (src) {
                const url = src.startsWith('http') ? src : new URL(src, source.baseUrl).href;
                console.log('✅ Found video via <video>: ', url);
                return url;
            }
        }

        // 3. <iframe>
        const iframe = doc.querySelector('iframe');
        if (iframe) {
            const iframeUrl = iframe.getAttribute('src');
            if (iframeUrl) {
                console.log('⚠ Found iframe, retrying inside:', iframeUrl);
                return await getVideoUrl(iframeUrl, source); // recursive
            }
        }

        // 4. <source> fallback
        const srcTag = doc.querySelector('source');
        if (srcTag && srcTag.getAttribute('src')) {
            const url = srcTag.getAttribute('src');
            console.log('✅ Found via <source>: ', url);
            return url;
        }

        throw new Error('Could not find video URL in page');

    } catch (error) {
        console.error('getVideoUrl error:', error);
        throw error;
    }
}