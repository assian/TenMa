class VideoPlayer {
    static isInitialized = false;
    static hls = null;
    static metadata = null; // video bilgileri (title, thumbnail, detailUrl)

    static init() {
        try {
            this.elements = {
                modal: document.getElementById('video-modal'),
                videoElement: document.getElementById('video-player'),
                closeBtn: document.querySelector('.close-btn'),
                downloadBtn: document.querySelector('.download-btn'),
                favoriteBtn: document.querySelector('#video-modal .favorite-btn')
            };
            if (!this.elements.modal || !this.elements.videoElement || !this.elements.closeBtn || !this.elements.favoriteBtn) {
                throw new Error('Video player elements not found in DOM');
            }

            this.elements.closeBtn.addEventListener('click', () => this.close());
            this.elements.modal.addEventListener('click', (e) => {
                if (e.target === this.elements.modal) this.close();
            });

            this.isInitialized = true;
            console.log('VideoPlayer initialized successfully');
            return true;
        } catch (error) {
            console.error('VideoPlayer initialization failed:', error);
            return false;
        }
    }

    static play(url, metadata = null) {
        if (!this.isInitialized) {
            console.error('VideoPlayer not initialized!');
            if (!this.init()) {
                alert('Video player failed to initialize. Please refresh the page.');
                return;
            }
        }

        if (!url) {
            alert('Geçersiz video URL');
            return;
        }

        // Download butonu
        this.elements.downloadBtn.onclick = () => {
            if (url) {
                const a = document.createElement('a');
                a.href = url;
                a.download = '';
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
            } else {
                alert('Video URL not found!');
            }
        };

        this.metadata = metadata;
        this._showModal();

        try {
            this._cleanup(); // Önceki video kaynağını temizle

            // Favori butonunu ayarla
            this._setupFavoriteButton(url);

            if (Hls.isSupported()) {
                this.hls = new Hls();
                this.hls.loadSource(url);
                this.hls.attachMedia(this.elements.videoElement);
                this.hls.on(Hls.Events.MANIFEST_PARSED, () => {
                    this.elements.videoElement.play()
                        .then(() => console.log('Video playback started'))
                        .catch(e => {
                            console.error('Playback failed:', e);
                            this.close();
                            alert('Video oynatılamadı: ' + e.message);
                        });
                });
            } else if (this.elements.videoElement.canPlayType('application/vnd.apple.mpegurl')) {
                this.elements.videoElement.src = url;
                this.elements.videoElement.play().catch(e => {
                    console.error('Playback failed:', e);
                    this.close();
                });
            } else {
                throw new Error('Tarayıcınız bu video formatını desteklemiyor');
            }
        } catch (error) {
            console.error('Video load error:', error);
            this.close();
            alert('Video yüklenemedi: ' + error.message);
        }
    }

    static _setupFavoriteButton(url) {
        const btn = this.elements.favoriteBtn;
        if (!btn || !this.metadata) return;

        const { detailUrl, title, thumbnail } = this.metadata;
        btn.setAttribute('data-video-id', detailUrl);
        btn.setAttribute('data-video-title', title);
        btn.setAttribute('data-video-thumb', thumbnail);
        const isFav = FavoritesManager.isFavorite(detailUrl);
        btn.innerHTML = isFav
            ? '<i class="fas fa-heart" style="color:#ff4757"></i>'
            : '<i class="far fa-heart"></i>';

        // Eski event listener'ı sil ve yenisini ata
        const newBtn = btn.cloneNode(true);
        btn.parentNode.replaceChild(newBtn, btn);
        this.elements.favoriteBtn = newBtn;

        newBtn.addEventListener('click', () => {
            FavoritesManager.toggleFavorite(detailUrl, title, thumbnail, url);
            const nowFav = FavoritesManager.isFavorite(detailUrl);
            newBtn.innerHTML = nowFav
                ? '<i class="fas fa-heart" style="color:#ff4757"></i>'
                : '<i class="far fa-heart"></i>';
        });
    }

    static close() {
        if (!this.isInitialized) return;

        console.log('Closing video player');
        this._hideModal();
        this._cleanup();
        this.metadata = null;
    }

    static _showModal() {
        this.elements.modal.style.display = 'block';
        document.body.style.overflow = 'hidden';
        console.log('Modal shown');
    }

    static _hideModal() {
        this.elements.modal.style.display = 'none';
        document.body.style.overflow = 'auto';
        console.log('Modal hidden');
    }

    static _cleanup() {
        if (this.hls) {
            this.hls.destroy();
            this.hls = null;
        }

        if (this.elements.videoElement) {
            this.elements.videoElement.pause();
            this.elements.videoElement.removeAttribute('src');
            this.elements.videoElement.load();
        }
    }
}

// Sayfa yüklendiğinde başlat
window.addEventListener('DOMContentLoaded', () => {
    setTimeout(() => {
        if (!VideoPlayer.init()) {
            console.error('VideoPlayer initialization failed after retry');
        }
    }, 500);
});