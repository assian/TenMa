class SourcesManager {
  static async init() {
    try {
      const response = await fetch('/api/sources');
      this.sources = await response.json();
      this.renderSourcesList();
    } catch (error) {
      console.error('Error loading sources:', error);
      this.sources = [];
    }
  }

  static getActiveSource() {
    return this.sources.find(source => source.active);
  }

  static async addSource(url) {
    try {
      // Fetch the remote sources.json
      const response = await fetch(`/proxy?url=${encodeURIComponent(url)}`);
      const newSources = await response.json();
      
      // Merge with existing sources
      const updatedSources = [...this.sources, ...newSources];
      
      // Save to server
      await fetch('/api/sources', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updatedSources)
      });
      
      return true;
    } catch (error) {
      console.error('Error adding source:', error);
      throw error;
    }
  }

  static async toggleSource(index, isActive) {
    this.sources[index].active = isActive;
    
    try {
      await fetch('/api/sources', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(this.sources)
      });
      
      return true;
    } catch (error) {
      console.error('Error updating source:', error);
      throw error;
    }
  }

  static async deleteSource(index) {
    this.sources.splice(index, 1);
    
    try {
      await fetch('/api/sources', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(this.sources)
      });
      
      return true;
    } catch (error) {
      console.error('Error deleting source:', error);
      throw error;
    }
  }

  static renderSourcesList() {
    const container = document.getElementById('sources-container');
    container.innerHTML = '';
    
    this.sources.forEach((source, index) => {
      const sourceItem = document.createElement('div');
      sourceItem.className = 'source-item';
      sourceItem.innerHTML = `
        <div class="source-name">${source.name}</div>
        <div class="source-actions">
          <label class="toggle-switch">
            <input type="checkbox" ${source.active ? 'checked' : ''}>
            <span class="toggle-slider"></span>
          </label>
          <button class="delete-btn" data-index="${index}">Delete</button>
        </div>
      `;
      
      container.appendChild(sourceItem);
      
      // Add event listeners
      const toggle = sourceItem.querySelector('input');
      toggle.addEventListener('change', async () => {
        await this.toggleSource(index, toggle.checked);
      });
      
      const deleteBtn = sourceItem.querySelector('.delete-btn');
      deleteBtn.addEventListener('click', async () => {
        if (confirm(`Are you sure you want to delete ${source.name}?`)) {
          await this.deleteSource(index);
          this.renderSourcesList();
        }
      });
    });
  }
}