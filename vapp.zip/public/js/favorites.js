class FavoritesManager {
    static favorites = {};

    static async init() {
        try {
            const response = await fetch('/favorites.json');
            this.favorites = await response.json();
        } catch (error) {
            this.favorites = {};
        }
        this.initFavoriteButtons();
    }

    static isFavorite(id) {
        return !!this.favorites[id];
    }

    static async toggleFavorite(id, title, thumbnail, url) {
        if (!id || !url) {
            console.error('Favori eklemek için ID ve URL gereklidir');
            return;
        }

        // URL mutlak hale getir
        try {
            const activeSource = SourcesManager.getActiveSource();
            if (!url.startsWith('http')) {
                url = new URL(url, activeSource.baseUrl).href;
            }
        } catch (e) {
            console.warn('Favori URL absolute yapılırken hata:', e);
        }

        try {
            const action = this.isFavorite(id) ? 'remove': 'add';
            const response = await fetch('/api/favorites', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    action,
                    video: {
                        id, title, thumbnail, url
                    }
                })
            });

            if (!response.ok) throw new Error('İşlem başarısız');
            this.favorites = (await response.json()).favorites;
            this.initFavoriteButtons();
        } catch (error) {
            console.error('Favori işlemi hatası:', error);
        }
    }

    static displayFavorites() {
        const container = document.getElementById('favorites-list');
        if (!container) return;

        if (!this.favorites || Object.keys(this.favorites).length === 0) {
            container.innerHTML = '<div class="empty">Henüz favori videonuz yok</div>';
            return;
        }

        container.innerHTML = Object.values(this.favorites).map(video => `
            <div class="video-card"
            data-detail-url="${video.url}"
            data-title="${video.title}"
            data-thumb="${video.thumbnail}" data-video-id="${video.id}">
            <div class="video-thumbnail">
            <img src="${video.thumbnail}" alt="${video.title}" onerror="this.src='/placeholder.jpg'">
            <button class="favorite-btn-page" data-video-id="${video.id}">
            <i class="fas fa-heart" style="color:#ff4757"></i>
            </button>
            </div>
            <div class="video-title">${video.title}</div>
            </div>
            `).join('');
        
        // Favori kartına tıklayınca player aç
        container.querySelectorAll('.video-card').forEach(card => {
            card.addEventListener('click', async (e) => {
                if (e.target.closest('.favorite-btn')) return;

                const detailUrl = card.getAttribute('data-video-id');
                const title = card.getAttribute('data-title');
                const thumbnail = card.getAttribute('data-thumb');
                const videoId = card.getAttribute('data-video-id');
                try {
                    const activeSource = SourcesManager.getActiveSource();
                    const videoUrl = await getVideoUrl(videoId, activeSource);
                    VideoPlayer.play(videoUrl, {detailUrl, title, thumbnail});
                } catch (err) {
                    console.error('Favori video açma hatası:', err);
                    alert('Favori video açılırken hata: ' + err.message);
                }
            });
        });

        this.initFavoriteButtons();
    }

    static initFavoriteButtons() {
        document.querySelectorAll('.favorite-btn').forEach(btn => {
            const id = btn.getAttribute('data-video-id');
            if (!id) return;
            btn.innerHTML = this.isFavorite(id)
            ? '<i class="fas fa-heart" style="color:#ff4757"></i>': '<i class="far fa-heart"></i>';
        });
    }
}